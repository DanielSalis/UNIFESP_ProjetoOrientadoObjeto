public interface Shape {
  String area();
}